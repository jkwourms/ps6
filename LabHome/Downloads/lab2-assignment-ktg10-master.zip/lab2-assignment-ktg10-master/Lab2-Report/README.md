# EECS301 Lab #2 Report

**Name: Kevin Griesser (ktg10@case.edu)**

## Introduction
This lab introduced us to the different constructs and syntax of programming in HDLs. Specifically, it showed me how to implement counters, registers, multiplexers, and lookup tables in Verilog. I also learned how to organize a design with various modules and then instantiating these modules in the TopLevel file. 
I completed this lab on one of the Glennan machines (Windows 7). It took about 3 hours, and roughly half of that time was spent working through various errors. Writing this report took about 15 minutes.


## Implementation Details
After finishing the implementation details in the Lab 2 Project Guide, which directed me to complete the CLS_Scanner_Module, the CLS_PWM_Interval_Timer, CLS_PWM_DutyCycle_Timer, and the CLS_LED_Output_Multiplexer, I ran into a few errors.

The first was just a weird Quartus warning where it was truncating the load value for my PWM interval timer, but that was fixed by changing 

localparam [PWM_REG_WIDTH:0] PWM_INV_LOADVAL = {1'b1, {PWM_REG_WIDTH{1'b0}}} - PWM_INV_TICKS + 1'b1; 

to 

localparam [PWM_REG_WIDTH:0] PWM_INV_LOADVAL = {1'b1, {PWM_REG_WIDTH{1'b0}}} - PWM_INV_TICKS **[PWM_REG_WIDTH:0]**  + 1'b1;


After this, ModelSim was returning some errors related to adding waveforms. This was due to naming differences in my Verilog files and the wave.do file. Some of the names specified in the Lab 2 Project Guide did not match the names expected by the wave.do script. One example is that the wave.do file expected the CLS_LED_Output_Multiplexer instance to be named led_output_mux, but the guide directed us to name this instance led_output_multiplexer. Changing these names, either in the Verilog files or the wave.do script, got rid of the errors. 

## Verification Results
Here is a screenshot of the ModelSim waveforms after running the simulation for 100ms -> ![Imagetag](waveform.png)

After loading the project onto the Dev board, I had a TA verify the 4 different scan rates on the board's LEDs, controlled by the two switches.


## Conclusions

This lab was incredibly helpful in learning how to design various constructs in Verilog. The guide was straight-forward to follow, aside from the naming issues, but still gave me the responsibility of implementing the modules. 

By working through some of the errors that popped up, I now feel more comfortable in Quartus and ModelSim and will hopefully identify/fix these issues more quickly in future labs.
